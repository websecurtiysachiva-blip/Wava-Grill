"use client";

import AboutHeroStory from "@/src/components/about/AboutHeroStory";
import AboutSection from "@/src/components/about/AboutSection";

export default function AboutPage() {
  return (
    <>
      <AboutHeroStory />
      <AboutSection />
    </>
  );
}
