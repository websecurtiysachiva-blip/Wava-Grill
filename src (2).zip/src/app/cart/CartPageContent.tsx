"use client";

import { useCart } from "@/src/context/CartContext";
import { useState } from "react";
export default function CartPageContent() {
  const { items, updateItem, removeItem, total } = useCart();
const [agree, setAgree] = useState(false);
  const deliveryFee = total > 0 ? 29 : 0;
  const taxes = total * 0.05;
  const grandTotal = total + deliveryFee + taxes;

  return (
    <div className="min-h-screen bg-[#f4ede7] px-6 md:px-20 py-12">

      <h1 className="text-3xl font-bold text-[#3b1d12] mb-10">
        Your Cart
      </h1>

      {items.length === 0 ? (
        <div className="bg-white p-10 rounded-2xl shadow text-center">
          <p className="text-gray-500 text-lg">
            Your cart is empty 🛒
          </p>
        </div>
      ) : (
        <div className="grid lg:grid-cols-3 gap-12">

          {/* LEFT - ITEMS */}
          <div className="lg:col-span-2 space-y-8">

            {items.map((item) => (
              <div
                key={item.id}
                className="bg-white p-6 rounded-2xl shadow-md flex flex-col md:flex-row gap-6 items-center"
              >

                {/* IMAGE */}
                <div className="w-24 h-24 rounded-xl overflow-hidden shadow">
                  <img
                    src={`http://localhost:5000${item.image}`}
                    alt={item.name}
                    className="w-full h-full object-cover"
                  />
                </div>

                {/* INFO */}
                <div className="flex-1">

                  <h3 className="text-lg font-semibold text-[#3b1d12]">
                    {item.name}
                  </h3>

                  <p className="text-sm text-gray-500 mt-1">
                    ₹ {item.price} per item
                  </p>

                  {/* QTY CONTROL */}
                  <div className="mt-4 flex items-center gap-4">

                    <div className="flex items-center border border-[#8b4513] rounded-lg overflow-hidden">

                      <button
                        onClick={() => updateItem(item.id, -1)}
                        className="px-4 py-2 text-[#8b4513] font-bold hover:bg-[#8b4513] hover:text-white transition"
                      >
                        -
                      </button>

                      <span className="px-4 font-semibold">
                        {item.quantity}
                      </span>

                      <button
                        onClick={() => updateItem(item.id, 1)}
                        className="px-4 py-2 text-[#8b4513] font-bold hover:bg-[#8b4513] hover:text-white transition"
                      >
                        +
                      </button>

                    </div>

                    <button
                      onClick={() => removeItem(item.id)}
                      className="text-red-500 text-sm hover:underline"
                    >
                      Remove
                    </button>

                  </div>

                </div>

                {/* ITEM TOTAL */}
                <div className="text-right">
                  <p className="text-lg font-bold text-[#8b4513]">
                    ₹ {(item.price * item.quantity).toFixed(2)}
                  </p>
                </div>

              </div>
            ))}

          </div>

          {/* RIGHT - BILL SUMMARY */}
          <div className="bg-white p-8 rounded-2xl shadow-xl h-fit lg:sticky lg:top-24">

            <h2 className="text-xl font-semibold text-[#3b1d12] mb-6">
              Bill Details
            </h2>

            <div className="space-y-4 text-gray-700">

              <div className="flex justify-between">
                <span>Subtotal</span>
                <span>₹ {total.toFixed(2)}</span>
              </div>

              <div className="flex justify-between">
                <span>Delivery Fee</span>
                <span>₹ {deliveryFee.toFixed(2)}</span>
              </div>

              <div className="flex justify-between">
                <span>Taxes (5%)</span>
                <span>₹ {taxes.toFixed(2)}</span>
              </div>

              <div className="border-t pt-4 flex justify-between text-xl font-bold text-[#3b1d12]">
                <span>Total</span>
                <span>₹ {grandTotal.toFixed(2)}</span>
              </div>

            </div>


            <div className="flex items-center gap-3 mt-6">
  <input
    type="checkbox"
    checked={agree}
    onChange={() => setAgree(!agree)}
    className="w-4 h-4 accent-[#8b4513]"
  />
  <span className="text-sm text-gray-600">
    I agree to the Terms & Conditions
  </span>
</div>

         <button
  disabled={!agree}
  className={`mt-8 w-full py-4 rounded-xl font-semibold transition shadow-lg
    ${
      agree
        ? "bg-[#8b4513] text-white hover:bg-[#6d3410]"
        : "bg-gray-300 text-gray-500 cursor-not-allowed"
    }
  `}
>
  Proceed to Checkout
</button>

          </div>

        </div>
      )}

    </div>
  );
}