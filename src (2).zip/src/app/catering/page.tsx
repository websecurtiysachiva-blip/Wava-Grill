"use client";

import CateringHero from "@/src/components/catering/CateringHero";
import CateringPackages from "@/src/components/catering/CateringPackages";

export default function CateringPage() {
  return (
    <>
      <CateringHero />
      <CateringPackages />
    </>
  );
}
