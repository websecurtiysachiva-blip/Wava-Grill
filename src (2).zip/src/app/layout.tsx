"use client";

import "./globals.css";
import Navbar from "../components/Navbar";
import Footer from "../components/Footer";
import { usePathname } from "next/navigation";
import React from "react";

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const pathname = usePathname();

  const hideLayout = ["/login", "/delivery", "/delivery-menu", "/cart"].includes(pathname);

  return (
    <html lang="en">
      <body className="bg-black text-white overflow-x-hidden scroll-smooth">

        {!hideLayout && <Navbar />}

        <main
          className={
            hideLayout
              ? ""
              : "min-h-screen pt-24 bg-black"
          }
        >
          {children}
        </main>

        {!hideLayout && <Footer />}

      </body>
    </html>
  );
}