"use client";

import { useEffect, useState } from "react";

type CartItem = {
  id: number;
  name: string;
  price: number;
  quantity: number;
};

export default function CartSidebar() {
  const [items, setItems] = useState<CartItem[]>([]);
  const userId = 1;

  useEffect(() => {
    fetchCart();

    window.addEventListener("cartUpdated", fetchCart);
    return () => {
      window.removeEventListener("cartUpdated", fetchCart);
    };
  }, []);

  const fetchCart = async () => {
    const res = await fetch(
      `http://localhost:5000/api/cart/${userId}`
    );
    const data = await res.json();
    setItems(data.items || []);
  };

  const total = items.reduce(
    (sum, item) => sum + item.price * item.quantity,
    0
  );

  const updateQty = async (id: number, change: number) => {
  await fetch("http://localhost:5000/api/cart/update", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      cart_item_id: id,
      change,
    }),
  });

  fetchCart();
};

const removeItem = async (id: number) => {
  await fetch(`http://localhost:5000/api/cart/remove/${id}`, {
    method: "DELETE",
  });

  fetchCart();
};

return (
  <div>

    <h2 className="text-2xl font-bold text-[#3b1d12] mb-8">
      Your Cart
    </h2>

    {items.length === 0 ? (
      <p className="text-gray-500 text-sm">
        Your cart is empty
      </p>
    ) : (
      <>
        <div className="space-y-6">

          {items.map((item) => (
            <div
              key={item.id}
              className="bg-white rounded-xl p-4 shadow-sm border border-gray-100"
            >
              <div className="flex justify-between items-start">

                <div className="flex-1">

                  <h3 className="font-semibold text-[#3b1d12]">
                    {item.name}
                  </h3>

                  {/* Quantity Controls */}
                  <div className="flex items-center gap-3 mt-3">

                    <button
                      onClick={() => updateQty(item.id, -1)}
                      className="w-8 h-8 flex items-center justify-center border border-[#8b4513] rounded-md text-[#8b4513] hover:bg-[#8b4513] hover:text-white transition"
                    >
                      -
                    </button>

                    <span className="font-semibold w-6 text-center">
                      {item.quantity}
                    </span>

                    <button
                      onClick={() => updateQty(item.id, 1)}
                      className="w-8 h-8 flex items-center justify-center border border-[#8b4513] rounded-md text-[#8b4513] hover:bg-[#8b4513] hover:text-white transition"
                    >
                      +
                    </button>

                  </div>

                </div>

                <div className="text-right">

                  <p className="font-semibold text-[#8b4513]">
                    ₹ {(item.price * item.quantity).toFixed(2)}
                  </p>

                  <button
                    onClick={() => removeItem(item.id)}
                    className="text-xs text-red-500 mt-2 hover:underline"
                  >
                    Remove
                  </button>

                </div>

              </div>
            </div>
          ))}

        </div>

        {/* Summary */}
        <div className="mt-10 border-t pt-6">

          <div className="flex justify-between mb-3 text-gray-600">
            <span>Subtotal</span>
            <span>₹ {total.toFixed(2)}</span>
          </div>

          <div className="flex justify-between mb-6 text-gray-600">
            <span>Taxes</span>
            <span>₹ {(total * 0.05).toFixed(2)}</span>
          </div>

          <div className="flex justify-between text-lg font-bold text-[#3b1d12] mb-6">
            <span>Total</span>
            <span>
              ₹ {(total + total * 0.05).toFixed(2)}
            </span>
          </div>

          <button className="w-full bg-[#8b4513] text-white py-4 rounded-xl font-semibold hover:bg-[#6d3410] transition shadow-lg">
            Proceed to Checkout
          </button>

        </div>

      </>
    )}

  </div>
);

}