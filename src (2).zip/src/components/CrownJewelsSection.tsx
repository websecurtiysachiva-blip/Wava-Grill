"use client";

import Image from "next/image";

export default function CrownJewelsSection() {
  return (
    <section className="w-full bg-[#f3f3f3] py-20 lg:py-32 px-4 sm:px-6 lg:px-8">
      
      <div className="max-w-6xl mx-auto text-center mb-16">
        <h3 className="text-sm uppercase tracking-[0.3em] text-[#7A1E12] font-semibold mb-4">
          Crown Collection
        </h3>

        <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-[#7A1E12] leading-tight">
          The Secret Behind Every Bold Flavor
        </h2>

        <p className="mt-4 text-gray-600 text-base sm:text-lg">
          Crafted with Passion. Perfected with Precision.
        </p>
      </div>

      <div className="max-w-7xl mx-auto">

        <div className="relative rounded-[50px] overflow-hidden px-6 sm:px-12 lg:px-20 py-14 lg:py-20 
        bg-gradient-to-br from-[#7A1E12] via-[#8E2315] to-[#65160E] shadow-2xl">

          <div className="flex flex-col lg:flex-row items-center gap-14">

            <div className="flex-1 text-white">

              <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-[#F5B400] mb-6 tracking-wide">
                Crown Jewels
              </h2>

              <p className="text-sm sm:text-base lg:text-lg leading-relaxed text-gray-100 max-w-xl">
                Your content will go here. You can describe your premium sauces,
                secret recipes, or powerful brand storytelling. Keep it elegant,
                rich, and luxurious to elevate your brand identity.
              </p>

              <div className="mt-8 h-1 w-24 bg-[#F5B400] rounded-full" />
            </div>

            <div className="flex-1 flex justify-center lg:justify-end">

              <div className="relative group max-w-md w-full">

                <div className="absolute -inset-4 bg-gradient-to-r from-yellow-400 via-yellow-300 to-yellow-500 rounded-[40px] blur-xl opacity-40 group-hover:opacity-60 transition duration-500"></div>

                <div className="relative bg-[#F5B400] p-2 rounded-[35px] shadow-2xl">

                  <div className="bg-white rounded-[30px] p-4">

                    <Image
                      src="/images/crown.png"
                      alt="Crown Jewel Sauces"
                      width={600}
                      height={600}
                      className="rounded-[20px] object-cover w-full h-auto transition duration-500 group-hover:scale-105"
                    />

                  </div>
                </div>

              </div>

            </div>

          </div>

          <div className="absolute top-0 right-0 w-72 h-72 bg-white/5 rounded-full blur-3xl"></div>

        </div>

      </div>
    </section>
  );
}
