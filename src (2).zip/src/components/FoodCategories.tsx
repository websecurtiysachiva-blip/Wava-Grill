"use client";

import { useRef, useState, useEffect } from "react";
import Image from "next/image";

const categories = [
  { name: "Dosa", image: "/images/dosa.png" },
  { name: "Biryani", image: "/images/dosa.png" },
  { name: "Pizza", image: "/images/dosa.png" },
  { name: "Burger", image: "/images/dosa.png" },
  { name: "North Indian", image: "/images/dosa.png" },
  { name: "Chinese", image: "/images/dosa.png" },
  { name: "Rolls", image: "/images/dosa.png" },
  { name: "Ice Cream", image: "/images/dosa.png" },
  { name: "Cake", image: "/images/dosa.png" },
    { name: "Biryani", image: "/images/dosa.png" },
  { name: "Pizza", image: "/images/dosa.png" },
  { name: "Burger", image: "/images/dosa.png" },
  { name: "North Indian", image: "/images/dosa.png" },
  { name: "Chinese", image: "/images/dosa.png" },
  { name: "Rolls", image: "/images/dosa.png" },
  { name: "Ice Cream", image: "/images/dosa.png" },
  { name: "Cake", image: "/images/dosa.png" },
];

export default function FoodCategories() {
  const scrollRef = useRef<HTMLDivElement>(null);

  const [canScrollLeft, setCanScrollLeft] = useState(false);
  const [canScrollRight, setCanScrollRight] = useState(true);

  const checkScroll = () => {
    const el = scrollRef.current;
    if (!el) return;

    setCanScrollLeft(el.scrollLeft > 0);
    setCanScrollRight(
      el.scrollLeft + el.clientWidth < el.scrollWidth - 5
    );
  };

  useEffect(() => {
    checkScroll();
    const el = scrollRef.current;
    el?.addEventListener("scroll", checkScroll);
    return () => el?.removeEventListener("scroll", checkScroll);
  }, []);

  const scroll = (direction: "left" | "right") => {
    if (!scrollRef.current) return;
    scrollRef.current.scrollBy({
      left: direction === "left" ? -400 : 400,
      behavior: "smooth",
    });
  };

  return (
    <section className="w-full py-16 bg-[#f8f6f3] relative">
      <div className="max-w-7xl mx-auto px-6 relative">

        {/* Heading */}
        <h2 className="text-3xl font-bold text-gray-900 mb-12">
          What's on your mind?
        </h2>

        {/* LEFT ARROW */}
     {canScrollLeft && (
  <button
    onClick={() => scroll("left")}
    className="absolute left-0 top-[60%] -translate-y-1/2 z-20
               w-12 h-12 rounded-full 
               bg-black text-white
               shadow-lg
               flex items-center justify-center
               hover:bg-red-600 transition duration-300"
  >
    <span className="text-2xl font-bold">‹</span>
  </button>
)}

        {/* RIGHT ARROW */}
    {canScrollRight && (
  <button
    onClick={() => scroll("right")}
    className="absolute right-0 top-[60%] -translate-y-1/2 z-20
               w-12 h-12 rounded-full 
               bg-black text-white
               shadow-lg
               flex items-center justify-center
               hover:bg-red-600 transition duration-300"
  >
    <span className="text-2xl font-bold">›</span>
  </button>
)}

        {/* Fade Effect Left */}
        <div className="absolute left-0 top-0 h-full w-16 bg-gradient-to-r from-[#f8f6f3] to-transparent pointer-events-none z-10" />

        {/* Fade Effect Right */}
        <div className="absolute right-0 top-0 h-full w-16 bg-gradient-to-l from-[#f8f6f3] to-transparent pointer-events-none z-10" />

        {/* Scroll Container */}
        <div
          ref={scrollRef}
          className="flex gap-12 overflow-x-auto scroll-smooth scrollbar-hide px-10"
        >
          {categories.map((item, index) => (
            <div
              key={index}
              className="flex-shrink-0 flex flex-col items-center cursor-pointer group transition"
            >
              <div className="relative w-28 h-28 sm:w-32 sm:h-32 
                              bg-white rounded-full shadow-md
                              flex items-center justify-center
                              group-hover:shadow-xl
                              transition duration-300">
                <Image
                  src={item.image}
                  alt={item.name}
                  fill
                  className="object-contain p-4 group-hover:scale-110 transition duration-300"
                />
              </div>

              <p className="mt-4 text-gray-800 font-medium text-center">
                {item.name}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}