"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import Image from "next/image";
import {
  FaFacebookF,
  FaInstagram,
  FaTwitter,
  FaYoutube,
  FaPhone,
  FaMapMarkerAlt,
  FaEnvelope,
} from "react-icons/fa";

export default function Footer() {
  return (
    <footer className="relative bg-[#0b0b0b] text-gray-300 pt-28 pb-14 overflow-hidden">

      {/* Animated Gradient Top Border */}
      <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-orange-500 via-pink-500 to-yellow-400 animate-gradient-x" />

      <div className="max-w-7xl mx-auto px-8 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-16">

        {/* Brand Section */}
   {/* Brand Section */}
<motion.div
  initial={{ opacity: 0, y: 40 }}
  whileInView={{ opacity: 1, y: 0 }}
  transition={{ duration: 0.6 }}
>
  <div className="flex items-center gap-3 mb-6">
    <Image
      src="/images/oo.png"
      alt="GrillPro Logo"
      width={50}
      height={50}
      className="object-contain"
    />
    <h2 className="text-3xl font-bold text-white">
    WAVA GRILL 
    </h2>
  </div>

  <p className="text-sm text-gray-400 leading-relaxed mb-6">
    Premium quality meals crafted with passion.
    Experience taste, health, and rewards — all in one place.
  </p>

  <div className="flex gap-4 text-lg">
    <FaFacebookF className="hover:text-orange-400 transition cursor-pointer" />
    <FaInstagram className="hover:text-orange-400 transition cursor-pointer" />
    <FaTwitter className="hover:text-orange-400 transition cursor-pointer" />
    <FaYoutube className="hover:text-orange-400 transition cursor-pointer" />
  </div>
</motion.div>

        {/* Quick Links */}
        <div>
          <h3 className="text-xl font-semibold text-white mb-6">
            Quick Links
          </h3>
          <ul className="space-y-3 text-sm">
            <li><Link href="/" className="hover:text-orange-400 transition">Home</Link></li>
            <li><Link href="/menu" className="hover:text-orange-400 transition">Menu</Link></li>
            <li><Link href="/loyalty" className="hover:text-orange-400 transition">Loyalty</Link></li>
            <li><Link href="/contact" className="hover:text-orange-400 transition">Contact</Link></li>
          </ul>
        </div>

        {/* Support */}
        <div>
          <h3 className="text-xl font-semibold text-white mb-6">
            Support
          </h3>
          <ul className="space-y-3 text-sm">
            <li><Link href="#" className="hover:text-orange-400 transition">Privacy Policy</Link></li>
            <li><Link href="#" className="hover:text-orange-400 transition">Terms of Service</Link></li>
            <li><Link href="#" className="hover:text-orange-400 transition">FAQ</Link></li>
            <li><Link href="#" className="hover:text-orange-400 transition">Help Center</Link></li>
          </ul>
        </div>

        {/* Contact Info */}
        <div>
          <h3 className="text-xl font-semibold text-white mb-6">
            Contact
          </h3>
          <ul className="space-y-4 text-sm text-gray-400">
            <li className="flex items-center gap-3">
              <FaMapMarkerAlt className="text-orange-500" />
              123 Main Street, New York
            </li>
            <li className="flex items-center gap-3">
              <FaPhone className="text-orange-500" />
              +1 234 567 890
            </li>
            <li className="flex items-center gap-3">
              <FaEnvelope className="text-orange-500" />
              support@grill.com
            </li>
          </ul>
        </div>

        {/* Newsletter + App Download */}
        <div>
          <h3 className="text-xl font-semibold text-white mb-6">
            Stay Updated
          </h3>

          <div className="flex mb-6">
            <input
              type="email"
              placeholder="Your email"
              className="w-full px-4 py-3 rounded-l-lg bg-gray-800 text-sm focus:outline-none"
            />
            <button className="px-5 py-3 bg-orange-500 text-white rounded-r-lg hover:bg-orange-600 transition">
              Subscribe
            </button>
          </div>

          <div className="text-sm text-gray-400">
            Download Our App
          </div>

          <div className="flex gap-4 mt-4">
            <img src="/images/appstore.png" className="w-28 hover:scale-105 transition" />
            <img src="/images/playstore.png" className="w-28 hover:scale-105 transition" />
          </div>
        </div>

      </div>

      {/* Divider */}
      <div className="border-t border-gray-800 mt-20 pt-8 text-center text-sm text-gray-500">
        © {new Date().getFullYear()} wavagrill. All Rights Reserved.
      </div>

    </footer>
  );
}