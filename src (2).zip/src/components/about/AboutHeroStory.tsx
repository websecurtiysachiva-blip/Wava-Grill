"use client";

export default function AboutPage() {
  return (
    <div className="w-full">

      {/* ================= HERO SECTION ================= */}
      <section className="relative w-full h-[80vh] overflow-hidden">

        {/* IMAGE */}
        <img
          src="/images/about-banner.jpg"
          className="absolute inset-0 w-full h-full object-cover"
        />

        {/* OVERLAY */}
        <div className="absolute inset-0 bg-black/60"></div>

        {/* LEFT TEXT */}
        <div className="absolute left-5 md:left-16 top-1/2 -translate-y-1/2 text-white max-w-sm md:max-w-md">
          <h2 className="text-2xl md:text-4xl font-bold mb-3">
            Fresh Mediterranean Taste
          </h2>
          <p className="text-sm md:text-lg text-gray-200">
            Authentic halal meals prepared with love & tradition.
          </p>
        </div>

        {/* RIGHT TEXT */}
        <div className="absolute right-5 md:right-16 top-1/2 -translate-y-1/2 text-white text-right max-w-sm md:max-w-md">
          <h2 className="text-2xl md:text-4xl font-bold mb-3">
            Fast Delivery
          </h2>
          <p className="text-sm md:text-lg text-gray-200">
            Hot & delicious meals delivered to your doorstep.
          </p>
        </div>

        {/* CENTER TEXT */}
        <div className="absolute inset-0 flex items-center justify-center">
          <h1 className="text-white text-4xl md:text-6xl font-bold tracking-wide">
            About Us
          </h1>
        </div>

      </section>


      {/* ================= RED STRIP ================= */}
      <section className="bg-gradient-to-r from-red-600 to-red-800 py-10 text-center shadow-lg">
        <h2 className="text-white text-xl md:text-4xl font-semibold tracking-wide">
          Serving Fresh Mediterranean Food Since 1990
        </h2>
      </section>


      {/* ================= OUR STORY ================= */}
<section id="our-story" className="scroll-mt-32 py-24 px-6">




        <div className="max-w-7xl mx-auto grid md:grid-cols-2 gap-16 items-center">

          {/* TEXT */}
          <div className="space-y-5">
            <h2 className="text-3xl md:text-5xl font-bold text-gray-900">
              Our Story
            </h2>

            <p className="text-gray-600 leading-relaxed">
              Wava Halal Grill is a locally owned Mediterranean restaurant
              dedicated to bringing authentic New York-style halal street
              food to the Texas community.
            </p>

            <p className="text-gray-600 leading-relaxed">
              Inspired by the famous halal food carts of New York City,
              our journey began with a simple mission — to provide
              high-quality, affordable, and delicious halal meals
              made with fresh ingredients and traditional recipes.
            </p>

            <p className="text-gray-600 leading-relaxed">
              From our original Dallas location to our Richardson
              branch opened in 2022, we have proudly served
              thousands of customers who trust us for our taste,
              consistency, and hospitality.
            </p>

            <p className="text-gray-600 leading-relaxed">
              Today, we continue to grow while maintaining our
              promise of delivering fresh, flavorful Mediterranean
              meals every day.
            </p>
          </div>

          {/* IMAGE */}
          <div className="relative group">
            <img
              src="/images/story.jpg"
              className="rounded-3xl shadow-2xl w-full h-[450px] object-cover transition duration-500 group-hover:scale-105"
            />
            <div className="absolute inset-0 rounded-3xl bg-black/10 group-hover:bg-black/20 transition"></div>
          </div>

        </div>
      </section>


  {/* ================= WHY CHOOSE US ================= */}
<section id="team" className="scroll-mt-32 py-24 px-6">


  <div className="max-w-7xl mx-auto text-center mb-16">
    <h2 className="text-3xl md:text-5xl font-bold text-gray-900">
      Why Choose Us
    </h2>
    <p className="text-gray-500 mt-3">
      Experience the taste of real Mediterranean street food
    </p>
  </div>

  <div className="max-w-7xl mx-auto grid sm:grid-cols-2 md:grid-cols-4 gap-10">

    {/* CARD 1 */}
    <div className="group relative p-8 rounded-3xl bg-white shadow-xl hover:shadow-red-300 hover:-translate-y-3 transition duration-300 overflow-hidden">

      <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-red-500 to-yellow-400"></div>

      <div className="text-4xl mb-4 group-hover:scale-110 transition">
        🥗
      </div>

      <h3 className="font-semibold text-xl mb-2">
        Fresh Ingredients
      </h3>

      <p className="text-gray-600 text-sm">
        Premium halal ingredients used for authentic taste.
      </p>

    </div>


    {/* CARD 2 */}
    <div className="group relative p-8 rounded-3xl bg-white shadow-xl hover:shadow-red-300 hover:-translate-y-3 transition duration-300 overflow-hidden">

      <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-yellow-400 to-red-500"></div>

      <div className="text-4xl mb-4 group-hover:scale-110 transition">
        🚚
      </div>

      <h3 className="font-semibold text-xl mb-2">
        Fast Delivery
      </h3>

      <p className="text-gray-600 text-sm">
        Hot & fresh meals delivered quickly.
      </p>

    </div>


    {/* CARD 3 */}
    <div className="group relative p-8 rounded-3xl bg-white shadow-xl hover:shadow-red-300 hover:-translate-y-3 transition duration-300 overflow-hidden">

      <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-red-500 to-orange-400"></div>

      <div className="text-4xl mb-4 group-hover:scale-110 transition">
        🍗
      </div>

      <h3 className="font-semibold text-xl mb-2">
        Authentic Taste
      </h3>

      <p className="text-gray-600 text-sm">
        Real Mediterranean street-style flavors.
      </p>

    </div>


    {/* CARD 4 */}
    <div className="group relative p-8 rounded-3xl bg-white shadow-xl hover:shadow-red-300 hover:-translate-y-3 transition duration-300 overflow-hidden">

      <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-orange-400 to-red-600"></div>

      <div className="text-4xl mb-4 group-hover:scale-110 transition">
        🤝
      </div>

      <h3 className="font-semibold text-xl mb-2">
        Friendly Service
      </h3>

      <p className="text-gray-600 text-sm">
        Warm & welcoming customer experience.
      </p>

    </div>

  </div>

</section>


    </div>
  );
}
