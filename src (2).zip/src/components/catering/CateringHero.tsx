"use client";

import { motion } from "framer-motion";
import Image from "next/image";

export default function CateringGallery() {

  const leftVariant = {
    hidden: { x: -300, opacity: 0, scale: 0.9 },
    show: {
      x: 0,
      opacity: 1,
      scale: 1,
      transition: { duration: 1 }
    }
  };

  const rightVariant = {
    hidden: { x: 300, opacity: 0, scale: 0.9 },
    show: {
      x: 0,
      opacity: 1,
      scale: 1,
      transition: { duration: 1 }
    }
  };

  return (
    <section className="w-screen min-h-screen bg-black overflow-hidden">

      <div className="grid md:grid-cols-2 w-full h-full">

        {/* LEFT IMAGE */}
        <motion.div
          variants={leftVariant}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true }}
          whileHover={{ scale: 1.03 }}
          className="relative h-[80vh] overflow-hidden"
        >
          <Image
            src="/images/catering1.jpg"
            alt="Catering"
            fill
            sizes="50vw"
            className="object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent" />
        </motion.div>

        {/* RIGHT IMAGE */}
        <motion.div
          variants={rightVariant}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true }}
          whileHover={{ scale: 1.03 }}
          className="relative h-[80vh] overflow-hidden"
        >
          <Image
            src="/images/catering2.jpg"
            alt="Catering"
            fill
            sizes="50vw"
            className="object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent" />
        </motion.div>

      </div>

    </section>
  );
}