"use client";

import { motion } from "framer-motion";

export default function CateringPackages() {
  return (
    <section className="w-full py-24 bg-gradient-to-b from-black to-[#111] text-white text-center">

      <h2 className="text-3xl md:text-5xl font-bold mb-12 text-red-500 tracking-wide">
        Catering Packages
      </h2>

      <div className="grid md:grid-cols-3 gap-10 max-w-6xl mx-auto px-6">

        {/* SMALL */}
        <motion.div
          whileHover={{ scale: 1.05 }}
          className="bg-gradient-to-br from-yellow-500 to-orange-500 
          rounded-3xl p-8 shadow-xl 
          transition-all duration-300"
        >
          <h3 className="text-2xl font-bold mb-2">Small Package</h3>
          <p className="opacity-80 mb-4">Serves 10-15 People</p>

          <div className="bg-white/20 backdrop-blur-md 
          rounded-full px-6 py-2 inline-block mt-3">
            Starter Pack
          </div>
        </motion.div>


        {/* MEDIUM */}
        <motion.div
          whileHover={{ scale: 1.05 }}
          className="bg-gradient-to-br from-red-500 to-pink-600 
          rounded-3xl p-8 shadow-xl 
          transition-all duration-300"
        >
          <h3 className="text-2xl font-bold mb-2">Medium Package</h3>
          <p className="opacity-80 mb-4">Serves 20-30 People</p>

          <div className="bg-white/20 backdrop-blur-md 
          rounded-full px-6 py-2 inline-block mt-3">
            Most Popular
          </div>
        </motion.div>


        {/* LARGE */}
        <motion.div
          whileHover={{ scale: 1.05 }}
          className="bg-gradient-to-br from-green-500 to-emerald-600 
          rounded-3xl p-8 shadow-xl 
          transition-all duration-300"
        >
          <h3 className="text-2xl font-bold mb-2">Large Package</h3>
          <p className="opacity-80 mb-4">Serves 40-50 People</p>

          <div className="bg-white/20 backdrop-blur-md 
          rounded-full px-6 py-2 inline-block mt-3">
            Party Pack
          </div>
        </motion.div>

      </div>

    </section>
  );
}