

// "use client";

// import Link from "next/link";
// import { usePathname } from "next/navigation";
// import { useEffect, useState } from "react";
// import { motion } from "framer-motion";
// import TopStrip from "./TopStrip";
// import Image from "next/image";

// export default function Navbar() {
//   const pathname = usePathname();
//   const [scrolled, setScrolled] = useState(false);

//   useEffect(() => {
//     const handleScroll = () => {
//       setScrolled(window.scrollY > 20);
//     };
//     window.addEventListener("scroll", handleScroll);
//     return () => window.removeEventListener("scroll", handleScroll);
//   }, []);

//   const navLinks = [
//     { name: "MENU", href: "/menu" },
//     { name: "LOCATIONS", href: "/locations" },
//     { name: "ABOUT", href: "/about" },
//     { name: "OFFERS", href: "/offers" },
//   ];

//   return (
//     <div className="sticky top-0 left-0 w-full z-50 bg-[#591A13]">

//       {/* Top Strip */}
//       <TopStrip />

//       {/* Main Header */}
//       <motion.header
//         initial={{ y: -60 }}
//         animate={{ y: 0 }}
//         transition={{ duration: 0.4 }}
//         className={`w-full transition-all duration-500 ${
//           scrolled
//             ? "bg-[#591A13]/95 backdrop-blur-xl shadow-lg py-2"
//             : "bg-[#591A13] py-4"
//         }`}
//       >
//    <div className="max-w-7xl mx-auto flex items-center px-4 sm:px-6 lg:px-8">


//           {/* Logo */}
//           <motion.div
//             whileHover={{ scale: 1.05 }}
//             transition={{ type: "spring", stiffness: 200 }}
//             className="flex items-center"
//           >
//             <Image
//               src="/images/ooo.png"
//               alt="Logo"
//               width={120}
//               height={120}
//               priority
//               className="w-[80px] sm:w-[100px] lg:w-[110px] h-auto object-contain drop-shadow-[0_0_10px_rgba(255,199,0,0.4)]"
//             />
//           </motion.div>
// {/* Right Section */}
// <div className="ml-auto flex items-center gap-6 lg:gap-10">

//   {/* Desktop Nav */}
//   <nav className="hidden md:flex gap-6 lg:gap-10 text-white font-semibold text-sm lg:text-base tracking-wide">
//     {navLinks.map((link) => (
//       <Link
//         key={link.name}
//         href={link.href}
//         className={`relative group transition-all duration-300 ${
//           pathname === link.href ? "text-[#FFC700]" : ""
//         }`}
//       >
//         {link.name}
//         <span className="absolute left-0 -bottom-2 h-[2px] w-0 bg-[#FFC700] transition-all duration-300 group-hover:w-full"></span>
//       </Link>
//     ))}
//   </nav>

//   {/* CTA Button */}
//   <motion.button
//     whileHover={{ scale: 1.07 }}
//     whileTap={{ scale: 0.95 }}
//     className="bg-[#FFC700] text-black px-4 sm:px-6 py-2 rounded-full font-bold text-sm sm:text-base shadow-lg transition-all duration-300"
//   >
//     ORDER NOW
//   </motion.button>

// </div>

     

//         {/* Bottom Glow Line */}
//         <div className="h-[2px] w-full bg-gradient-to-r from-transparent via-[#FFC700] to-transparent opacity-40 mt-3"></div>
//       </motion.header>
//     </div>
//   );
// }


"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import Image from "next/image";
import TopStrip from "./TopStrip";

export default function Navbar() {
  const pathname = usePathname();
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navLinks = [
    { name: "MENU", href: "/menu" },
    { name: "LOCATIONS", href: "/locations" },
    { name: "ABOUT", href: "/about" },
    { name: "OFFERS", href: "/offers" },
  ];

  return (
     <div className="sticky top-0 w-full z-50">

    {/* 🔴 TOP STRIP YAHAN ADD KARO */}
    <TopStrip />

      <motion.header
        initial={{ y: -60 }}
        animate={{ y: 0 }}
        transition={{ duration: 0.4 }}
        className="w-full py-4"
      >
        <div className="max-w-7xl mx-auto flex items-center px-4 sm:px-6 lg:px-8">

          {/* Logo Left */}
          <div className="flex items-center">
            <Image
              src="/images/ooo.png"
              alt="Logo"
              width={140}
              height={140}
              priority
              className="w-[110px] h-auto object-contain"
            />
          </div>

          {/* Right Section */}
          <div className="ml-auto flex items-center gap-8">

            {/* Desktop Nav */}
            <nav className="hidden md:flex gap-8 font-semibold text-sm tracking-wide uppercase">
              {navLinks.map((link) => {
                const isActive = pathname === link.href;

                return (
                  <Link
                    key={link.name}
                    href={link.href}
                    className={`transition-all duration-300 ${
                      isActive
                        ? "text-red-600"
                        : "text-white hover:text-red-600"
                    }`}
                  >
                    {link.name}
                  </Link>
                );
              })}
            </nav>

            {/* ORDER NOW Button */}
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="bg-red-600 hover:bg-red-700 text-white px-6 py-2 rounded-full font-bold text-sm transition-all duration-300"
            >
              ORDER NOW
            </motion.button>

          </div>
        </div>

        {/* Bottom subtle line */}
        <div className="h-[2px] w-full bg-gray-800 mt-4"></div>
      </motion.header>
    </div>
  );
}
